﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXERCICIO14.Presentation.UI
{
    public enum OpcaoMenu
    {
        CadastrarGado = 'a',
        DeletarGado = 'b',
        EditarGado = 'c',
        ListarCadastros = '1',
        RelatorioLeite = '2',
        RelatorioLeiteAposAbate = '3',
        RelatorioAlimento = '4',
        RelatorioAlimentoAposAbate = '5',
        GadosParaAbate = '6',
        Sair = '0'
    }
}
