﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXERCICIO14.Presentation.UI
{
    public enum OpcaoMenu
    {
        CadastrarGado = 'a',
        ListarCadastros = 'b',
        RelatorioLeite = '1',
        RelatorioAlimento = '2',
        RelatorioLeiteAposAbate = '3',
        RelatorioAlimentoAposAbate = '4',
        GadosParaAbate = '5',
        Sair = 'h'
    }
}
